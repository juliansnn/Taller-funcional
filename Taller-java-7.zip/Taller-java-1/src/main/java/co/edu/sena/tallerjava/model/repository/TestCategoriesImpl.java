package co.edu.sena.tallerjava.model.repository;

import co.edu.sena.tallerjava.model.Categories;

import java.sql.SQLException;

public class TestCategoriesImpl {
    public static void main(String[] args) throws SQLException {
        Repository<Categories> repository = new CategoryRepositoryImpl();

        System.out.println("========== saveObj Insert =========="); // Insert
        Categories cInsert = new Categories();
        cInsert.setCategory_name("S1000RR");
        repository.saveObj(cInsert);
        cInsert.setCategory_name("YAMAHA");
        repository.saveObj(cInsert);
        System.out.println("========== ListAllObj  ==========");
        repository.listAllObj().forEach(System.out::println);
        System.out.println();

        System.out.println("========== byIdObj  ==========");
        System.out.println(repository.byIdobj(1));
        System.out.println();

        System.out.println("========== saveObj  ==========");

        Categories cUpdate = new Categories();

        cUpdate.setCategory_id(2);
        cUpdate.setCategory_name("GIZER");

        repository.saveObj(cInsert);
        repository.listAllObj().forEach(System.out::println);
        System.out.println();


        System.out.println("========== deleteObj  ==========");
        repository.deleteObj(2);
        repository.listAllObj().forEach(System.out::println);

    }
} //TestCategoriesImpl

